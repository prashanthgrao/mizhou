package com.mizhou.data;

public enum Side {
    BUY,
    SELL;
}
