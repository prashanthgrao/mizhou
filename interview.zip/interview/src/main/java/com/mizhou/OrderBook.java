package com.mizhou;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.mizhou.data.Order;
import com.mizhou.data.Side;

public class OrderBook {
	
	private static final Logger log = LogManager.getLogger(OrderBook.class);

	private final String symbol;
	private final Comparator<Order> buyComparator = Comparator.comparing(Order::getPrice).reversed();
	private final Comparator<Order> sellComparator = Comparator.comparing(Order::getPrice);
	private final List<Order> buyOrders = new ArrayList<>();
	private final List<Order> sellOrders = new ArrayList<>();
	private int totalBuyQty = 0;
	private int totalSellQty = 0;

	
	public OrderBook(String symbol) {
		this.symbol = symbol;
	}
	
	public void addOrder(Order order) {
		if (order.getSide() == Side.BUY) {
			log.info("Adding Order in Buy side " + order.getOrderId());
			totalBuyQty += order.getQuantity();
			buyOrders.add(order);
			buyOrders.sort(buyComparator);
		} else {
			log.info("Adding Order in Sell side " + order.getOrderId());
			totalSellQty += order.getQuantity();
			sellOrders.add(order);
			sellOrders.sort(sellComparator);
		}
	}
	
	public void removeOrder(Order order) {
		if (order.getSide() == Side.BUY) {
			log.info("Removing Order in Buy side " + order.getOrderId());
			totalBuyQty -= order.getQuantity();
			buyOrders.remove(order);
			buyOrders.sort(buyComparator);
		} else {
			log.info("Removing Order in Sell side " + order.getOrderId());
			totalSellQty -= order.getQuantity();
			sellOrders.remove(order);
			sellOrders.sort(sellComparator);
		}
	}
	
	public void modifyOrder(Order originalOrder, Order newOrder) {
		log.info("Modifying order for " + originalOrder.getOrderId());
		removeOrder(originalOrder);
		addOrder(newOrder);
		log.info("Modified order for " + originalOrder.getOrderId());
	}

	public double getCurrentPrice(int quantity, Side side) {
		if (side == Side.BUY) {
			if (totalBuyQty < quantity) {
				log.info("Total buy quantity in order book less than requested");
				return Double.NaN;
			}
			return getPrice(buyOrders, quantity);
		} else {
			if (totalSellQty < quantity) {
				log.info("Total sell quantity in order book less than requested");
				return Double.NaN;
			}
			return getPrice(sellOrders, quantity);
		}
	}

	private static double getPrice(List<Order> orders, int quantityRequested) {
		double totalPrice = 0;
		int remainingQuantity = quantityRequested;
		for (int i=0; i < orders.size() && remainingQuantity > 0; i++) {
			Order order = orders.get(i);
			if (remainingQuantity >= order.getQuantity()) {
				remainingQuantity -= order.getQuantity();
				totalPrice += order.getPrice() * order.getQuantity();
			} else {
				totalPrice += order.getPrice() * remainingQuantity;
				remainingQuantity = 0;
			}
		}
		return totalPrice/quantityRequested;
	}

}
