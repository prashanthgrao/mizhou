package com.mizhou;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.mizhou.data.Order;
import com.mizhou.data.Side;


public class OrderHandlerImpl implements OrderHandler {
	
	private static final Logger log = LogManager.getLogger(OrderHandlerImpl.class);
	private final Map<Long, Order> cachedOrders = new HashMap<>();
	private final Map<String, OrderBook> symbolToOrderBook = new ConcurrentHashMap<>();
	

	@Override
	public void addOrder(Order order) {
		log.info("Received new order" + order.getOrderId());
		cachedOrders.put(order.getOrderId(), order);
		OrderBook orderBook = symbolToOrderBook.getOrDefault(order.getSymbol(), new OrderBook(order.getSymbol()));
		orderBook.addOrder(order);
		symbolToOrderBook.put(order.getSymbol(), orderBook);
		log.info("Added order" + order.getOrderId());
	}

	@Override
	public void modifyOrder(OrderModification orderModification) {
		log.info("Received modification of order " + orderModification.getOrderId());
		Order originalOrder = cachedOrders.get(orderModification.getOrderId());
		if (originalOrder != null) {
			Order newOrder = new Order(
					orderModification.getOrderId(),
					originalOrder.getSymbol(),
					originalOrder.getSide(),
					orderModification.getNewPrice(),
					orderModification.getNewQuantity());
			symbolToOrderBook.get(originalOrder.getSymbol()).modifyOrder(originalOrder, newOrder);;
			cachedOrders.remove(orderModification.getOrderId());
			log.info("Modified order" + orderModification.getOrderId());
		} else {
			throw new RuntimeException("Cannot modify an order which was not added");
		}
	}

	@Override
	public void removeOrder(long orderId) {
		log.info("Removing order for OrderId " + orderId);
		Order order = cachedOrders.get(orderId);
		if (order != null) {
			log.info("Removed order for OrderId " + orderId);
			symbolToOrderBook.get(order.getSymbol()).removeOrder(order);
		} else {
			throw new RuntimeException("Cannot remove order that was not added in the system");
		}
	}

	@Override
	public double getCurrentPrice(String symbol, int quantity, Side side) {
		log.info("Getting current price for Symbol " + symbol);
		OrderBook orderBook = symbolToOrderBook.get(symbol);
		if (orderBook != null) {
			double price = orderBook.getCurrentPrice(quantity, side);
			log.info("Priced order for " + symbol);
			return price;
		} else {
			throw new RuntimeException("Cannot price " + symbol + " since it is not added in order book");
		}
	}
	

}

