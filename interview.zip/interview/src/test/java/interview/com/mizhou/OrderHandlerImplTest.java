package interview.com.mizhou;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.mizhou.OrderHandler;
import com.mizhou.OrderHandlerImpl;
import com.mizhou.data.Side;

public class OrderHandlerImplTest {
	
private final OrderHandler orderHandler = new OrderHandlerImpl();
	
	@Test
	public void testOrderPrice() {
		ExampleData.buildExampleOrderBookFromReadMe(orderHandler);
		double price = orderHandler.getCurrentPrice("MSFT", 6, Side.SELL);
		assertEquals("Price not equals", 19.0, price, 0.0);
		price = orderHandler.getCurrentPrice("MSFT", 17, Side.SELL);
		assertEquals("Price not equals", 19.588, price, 0.01);
		price = orderHandler.getCurrentPrice("MSFT", 30, Side.SELL);
		assertEquals("Price not equals", 20.233, price, 0.01);
		price = orderHandler.getCurrentPrice("MSFT", 10, Side.BUY);
		assertEquals("Price not equals", 15.0, price, 0.01);
		price = orderHandler.getCurrentPrice("MSFT", 10000, Side.BUY);
		assertTrue(Double.isNaN(price));
		price = orderHandler.getCurrentPrice("MSFT", 10000, Side.SELL);
		assertTrue(Double.isNaN(price));
	}
	
}
